package com.dennis.tues.demo;

import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class ChatbotService {

    // Inject API key and URL from application properties
    @Value("${openai.api.key}")
    private String apiKey;

    @Value("${openai.api.url:https://api.openai.com/v1/chat/completions}")
    private String apiUrl;

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public String getChatbotResponse(String userMessage) {
        OkHttpClient client = new OkHttpClient();

        // Construct the JSON payload for the API request
        String requestBody = "{"
                + "\"model\":\"gpt-3.5-turbo\","
                + "\"messages\":["
                + "{\"role\":\"system\",\"content\":\"You are a helpful assistant.\"},"
                + "{\"role\":\"user\",\"content\":\"" + userMessage + "\"}]"
                + "}";

        // Build the HTTP request
        Request request = new Request.Builder()
                .url(apiUrl)
                .post(RequestBody.create(requestBody, JSON))
                .addHeader("Authorization", "Bearer " + apiKey)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                // Return the response body as a string
                return response.body().string();
            } else {
                return "Error: " + response.code() + " - " + response.message();
            }
        } catch (IOException e) {
            return "Error: Unable to communicate with OpenAI API - " + e.getMessage();
        }
    }
}
