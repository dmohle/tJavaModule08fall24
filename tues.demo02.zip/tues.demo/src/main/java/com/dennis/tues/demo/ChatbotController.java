package com.dennis.tues.demo;

import com.dennis.tues.demo.ChatbotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
public class ChatbotController {

    @Autowired
    private ChatbotService chatbotService;

    // Endpoint to handle chat requests
    @PostMapping
    public String getChatResponse(@RequestBody String userMessage) {
        // Call the ChatbotService to get a response
        return chatbotService.getChatbotResponse(userMessage);
    }
}
